# react-java-example
Example project on how to develop and build React application with Java
